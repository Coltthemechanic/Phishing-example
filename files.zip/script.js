// ======= CHANGE THIS to your YouTube video ID =======
const VIDEO_ID = "VIDEO_ID_HERE";
// ====================================================

let player = null;
let playerReady = false;
let started = false;

// Load the YouTube IFrame API
const tag = document.createElement("script");
tag.src = "https://www.youtube.com/iframe_api";
document.head.appendChild(tag);

// Called automatically by the YouTube API when it's loaded.
// Must be on window so the API can find it.
window.onYouTubeIframeAPIReady = function () {
  player = new YT.Player("player", {
    videoId: VIDEO_ID,
    playerVars: {
      playsinline: 1,   // keeps it in-page on iPhones instead of forcing native fullscreen
      controls: 1,      // set to 0 to hide controls
      rel: 0,           // no related videos from other channels at the end
      modestbranding: 1
    },
    events: {
      onReady: () => { playerReady = true; }
    }
  });
};

// First tap anywhere: reveal video, unmute, play
const tapzone = document.getElementById("tapzone");
tapzone.addEventListener("click", startVideo);
tapzone.addEventListener("touchend", startVideo);

function startVideo(e) {
  e.preventDefault();
  if (started) return;

  if (!playerReady) {
    // API still loading — retry briefly until ready
    setTimeout(() => startVideo(e), 150);
    return;
  }

  started = true;
  document.getElementById("videowrap").classList.add("active");
  tapzone.style.display = "none";

  player.unMute();
  player.setVolume(100);
  player.playVideo();
}
